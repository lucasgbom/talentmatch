<?php
    require_once('app/conexãoo/conexao.php');
	require_once('app/dao/ArtistaDAO.php');
	require_once('app/model/Artista.php');
	require_once('app/dao/UsuarioDAO.php');
	require_once('app/model/Usuario.php');
