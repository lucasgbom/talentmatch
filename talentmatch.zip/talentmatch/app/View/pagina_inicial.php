<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <a href="cadastro_artista.php"><button>Cadastrar artista</button></a> <br>
    <a href="cadastro_contratador.php"><button>Cadastrar contratador</button></a> <br>
    <a href="login_artista.php"><button>Login artista</button></a> <br>
    <a href="login_contratador.php"><button>Login contratador</button></a> <br>
</body>

</html>