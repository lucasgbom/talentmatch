<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Círculo com metade fora</title>
  <style>
    *{margin: 0px; padding: 0px;}
html{height: 100%;width: 100%;}
  
  </style>
</head>
<body>
<form action="../Model/dadosperfil.php" method="post" enctype="multipart/form-data">
  <input type="text" name="nome">
  <input type="file" name="arquivo">
    <button type="submit">Enviar</button>
</form>
</body>
</html>
